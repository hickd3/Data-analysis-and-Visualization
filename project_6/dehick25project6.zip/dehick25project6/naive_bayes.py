'''naive_bayes_multinomial.py
Naive Bayes classifier with Multinomial likelihood for discrete features
Dean Hickman
CS 251: Data Analysis and Visualization
Fall 2024
'''
import numpy as np

from classifier import Classifier

class NaiveBayes(Classifier):
    '''Naive Bayes classifier using Multinomial likeilihoods (discrete data belonging to any number of classes)'''
    def __init__(self, num_classes):
        '''Naive Bayes constructor

        TODO:
        - Call superclass constructor
        - Add placeholder instance variables the class prior probabilities and class likelihoods (assigned to None).
        You may store the priors and likelihoods themselves or the logs of them. Be sure to use variable names that make
        clear your choice of which version you are maintaining.
        '''
        super().__init__(num_classes)
        self.log_priors = None
        self.log_likelihoods = None

    def get_priors(self):
        '''Returns the class priors (or log of class priors if storing that)'''
        return self.log_priors

    def get_likelihoods(self):
        '''Returns the class likelihoods (or log of class likelihoods if storing that)'''
        return self.log_likelihoods

    def train(self, data, y):
        '''Train the Naive Bayes classifier so that it records the "statistics" of the training set:
        class priors (i.e. how likely an email is in the training set to be spam or ham?) and the
        class likelihoods (the probability of a word appearing in each class — spam or ham)

        Parameters:
        -----------
        data: ndarray. shape=(num_samps, num_features). Data to learn / train on.
        y: ndarray. shape=(num_samps,). Corresponding class of each data sample.

        TODO:
        - Compute the class priors and class likelihoods (i.e. your instance variables) that are needed for
        Bayes Rule. See equations in notebook.
        '''
        num_samps, num_features = data.shape[0], data.shape[1]
        classes = range(self.num_classes)
        priors = []
        for i in classes:
            lil_p = (np.count_nonzero(y == i))/num_samps
            priors.append(lil_p)

        self.log_priors = np.log(np.array(priors))

        M = num_features
        likelihoods = []
        for i in classes:
            T_c = np.sum(data[y == i])

            T_cw = np.sum(data[y == i], axis=0)
            likelihoods_i = []

            for j in range(num_features):
                likelihood = (T_cw[j]+1)/(T_c + M)
                likelihoods_i.append(likelihood)
        
            likelihoods.append(likelihoods_i)

        self.log_likelihoods = np.log(np.array(likelihoods))


    def predict(self, data):
        '''Combine the class likelihoods and priors to compute the posterior distribution. The
        predicted class for a test sample from `data` is the class that yields the highest posterior
        probability.

        Parameters:
        -----------
        data: ndarray. shape=(num_test_samps, num_features). Data to predict the class of
            Need not be the data used to train the network

        Returns:
        -----------
        ndarray of nonnegative ints. shape=(num_samps,). Predicted class of each test data sample.

        TODO:
        - For the test samples, we want to compute the log of the posterior by evaluating
        the the log of the right-hand side of Bayes Rule without the denominator (see notebook for
        equation). This can be done without loops.
        - Predict the class of each test sample according to the class that produces the largest
        log(posterior) probability (hint: this can also be done without loops).

        NOTE: Remember that you are computing the LOG of the posterior (see notebook for equation).
        NOTE: The argmax function could be useful here.
        '''
        log_posteriors = self.log_likelihoods @ data.T + self.log_priors.reshape(-1, 1)

        predictions = np.argmax(log_posteriors, axis=0)

        return predictions
